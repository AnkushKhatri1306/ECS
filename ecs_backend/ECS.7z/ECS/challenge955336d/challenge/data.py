"""Routines associated with the application data.
"""

courses = {}

def load_data():
    """Load the data from the json file.
    """
    pass


